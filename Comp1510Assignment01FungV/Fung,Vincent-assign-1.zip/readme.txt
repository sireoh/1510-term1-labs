Vincent Fung, A01380639, Set D, Feb 05 2024

This assignment is 100% complete.


------------------------
Question one (Change) status:

complete
[explanation if not complete, what is working/not working]

------------------------
Question two (Sqrt) status:

complete
[explanation if not complete, what is working/not working]

------------------------
Question three (Reverse) status:

complete
[explanation if not complete, what is working/not working]

------------------------
Question four (Pack) status:

complete
[explanation if not complete, what is working/not working]
